<?php

namespace App\Livewire\Social\MarketingCampaigns;

use App\Domain\Social\Actions\ArchiveMarketingCampaignPostAction;
use App\Domain\Social\Actions\RestoreMarketingCampaignPostAction;
use App\Domain\Social\Exceptions\MarketingCampaignPostArchiveException;
use Livewire\Component;
use Livewire\WithFileUploads;
use App\Models\MarketingCampaign;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use App\Domain\Social\Services\MarketingCampaignPostVersionMediaResolver;
use App\Domain\Social\Services\MarketingCampaignPostMediaUrlResolver;
use App\Domain\Social\Services\MarketingCampaignPostCalendarDateResolver;
use App\Domain\Social\Exceptions\MarketingCampaignPostMediaResolutionException;
use Illuminate\Support\Facades\Log;

class MarketingCampaignShow extends Component
{
    use WithFileUploads, AuthorizesRequests;

    public MarketingCampaign $campaign;
    public string $calendarDate;
    public string $postFilter = 'active';

    private MarketingCampaignPostVersionMediaResolver $mediaResolver;
    private MarketingCampaignPostMediaUrlResolver $urlResolver;
    private MarketingCampaignPostCalendarDateResolver $calendarDateResolver;

    public function boot(
        MarketingCampaignPostVersionMediaResolver $mediaResolver,
        MarketingCampaignPostMediaUrlResolver $urlResolver,
        MarketingCampaignPostCalendarDateResolver $calendarDateResolver
    ): void {
        $this->mediaResolver = $mediaResolver;
        $this->urlResolver = $urlResolver;
        $this->calendarDateResolver = $calendarDateResolver;
    }

    public function mount(MarketingCampaign $campaign)
    {
        $this->authorize('view', $campaign);
        $this->campaign = $campaign;
        $this->calendarDate = request('date', now()->toDateString());
    }

    public function setCalendarDate(string $date): void
    {
        try {
            $this->calendarDate = \Carbon\Carbon::parse($date)->toDateString();
        } catch (\Throwable) {
            $this->calendarDate = now()->toDateString();
        }
        $this->dispatch('marketing-campaign-detail-calendar-date-changed', date: $this->calendarDate);
    }

    public function goToPreviousCalendarMonth(): void
    {
        $this->calendarDate = \Carbon\Carbon::parse($this->calendarDate)->subMonth()->toDateString();
        $this->dispatch('marketing-campaign-detail-calendar-date-changed', date: $this->calendarDate);
    }

    public function goToNextCalendarMonth(): void
    {
        $this->calendarDate = \Carbon\Carbon::parse($this->calendarDate)->addMonth()->toDateString();
        $this->dispatch('marketing-campaign-detail-calendar-date-changed', date: $this->calendarDate);
    }

    // --- NUOVI STATI LIFECYCLE CAMPAGNA ---
    public bool $showCampaignModal = false;
    public array $campaignForm = [];

    public bool $showExtendModal = false;
    public array $extendForm = [];

    public bool $showRenewModal = false;
    public array $renewForm = [];

    public bool $showExtraModal = false;
    public array $extraForm = [];

    public bool $showInvoiceModal = false;
    public array $invoiceForm = [];
    public array $pendingPeriodsForInvoice = [];
    public array $pendingExtrasForInvoice = [];
    public array $customLines = [];
    // --------------------------------------


    public function fetchEvents()
    {
        $posts = $this->campaign->posts()
            ->with(['currentVersion', 'successfulPublications'])
            ->notArchived()
            ->calendarEligible()
            ->where('status', '!=', \App\Enums\Social\MarketingCampaignPostStatus::Cancelled)
            ->get();

        return $posts->map(function ($post) {
            $eventDate = $this->calendarDateResolver->resolve($post);

            if (! $eventDate) {
                return null;
            }

            return [
                'id' => $post->id,
                'title' => $post->title ?: 'Senza Titolo',
                'start' => $eventDate->format('Y-m-d\TH:i:s'),
                'allDay' => false,
                'url' => route('marketing-campaigns.posts.show', ['campaign' => $this->campaign->id, 'post' => $post->id]),
                'backgroundColor' => $post->status->color(),
                'borderColor' => $post->status->color(),
                'extendedProps' => [
                    'platform' => $post->content_type->label(),
                    'status' => $post->status->label(),
                ]
            ];
        })->filter()->values()->toArray();
    }

    private function publishedDates()
    {
        return $this->campaign->posts()
            ->with('successfulPublications')
            ->notArchived()
            ->calendarEligible()
            ->where('status', '!=', \App\Enums\Social\MarketingCampaignPostStatus::Cancelled)
            ->get()
            ->map(fn ($post) => $this->calendarDateResolver->resolve($post)?->format('Y-m-d'))
            ->filter()
            ->unique()
            ->values()
            ->all();
    }

    public function archivePost(int $postId, ArchiveMarketingCampaignPostAction $action): void
    {
        $post = $this->campaign->posts()
            ->with('publications')
            ->findOrFail($postId);

        $this->authorize('update', $post);

        try {
            $action->execute($post, auth()->user());
            session()->flash('success', 'Post archiviato. È stato nascosto dalle viste operative, senza eliminare contenuti social o storico tecnico.');
        } catch (MarketingCampaignPostArchiveException $exception) {
            session()->flash('error', 'Il post non può essere archiviato perché è pubblicato, parzialmente pubblicato o ancora in elaborazione.');
        }
    }

    public function restorePost(int $postId, RestoreMarketingCampaignPostAction $action): void
    {
        $post = $this->campaign->posts()
            ->onlyArchived()
            ->findOrFail($postId);

        $this->authorize('update', $post);

        $action->execute($post);
        session()->flash('success', 'Post ripristinato nelle viste operative.');
    }

    // --- NUOVI METODI LIFECYCLE CAMPAGNA ---

    public function openCampaignModal()
    {
        $this->authorize('update', $this->campaign);
        $this->campaignForm = [
            'client_id' => $this->campaign->client_id,
            'name' => $this->campaign->name,
            'description' => $this->campaign->description,
            'status' => $this->campaign->status->value,
            'starts_at' => $this->campaign->starts_at ? $this->campaign->starts_at->format('Y-m-d') : null,
            'ends_at' => $this->campaign->ends_at ? $this->campaign->ends_at->format('Y-m-d') : null,
            'monthly_fee' => $this->campaign->monthly_fee,
            'notes' => $this->campaign->notes,
            'publication_mode' => $this->campaign->publication_mode->value,
            'client_review_required' => $this->campaign->client_review_required,
        ];
        $this->showCampaignModal = true;
    }

    public function closeCampaignModal()
    {
        $this->showCampaignModal = false;
    }

    public function saveCampaign(\App\Domain\Social\Actions\UpdateMarketingCampaignAction $action)
    {
        $this->authorize('update', $this->campaign);

        $this->validate([
            'campaignForm.name' => 'required|string|max:255',
            'campaignForm.monthly_fee' => 'nullable|numeric|min:0',
            'campaignForm.publication_mode' => 'required|in:manual,automatic',
            'campaignForm.client_review_required' => 'required|boolean',
        ]);

        $action->execute($this->campaign, $this->campaignForm);
        $this->closeCampaignModal();
        $this->dispatch('campaign-updated');
    }

    public function openExtendModal()
    {
        $this->authorize('update', $this->campaign);

        // Suggeriamo come "from_date" il giorno successivo all'ends_at attuale, se c'è
        $suggestedFrom = $this->campaign->ends_at ? clone $this->campaign->ends_at : now();
        if ($this->campaign->ends_at) {
            $suggestedFrom->addDay();
        }

        $this->extendForm = [
            'from_date' => $suggestedFrom->format('Y-m-d'),
            'to_date' => null,
            'amount' => $this->campaign->monthly_fee,
            'description' => 'Prolungamento gestione',
        ];
        $this->showExtendModal = true;
    }

    public function closeExtendModal()
    {
        $this->showExtendModal = false;
    }

    public function extendCampaign(\App\Domain\Social\Actions\ExtendMarketingCampaignAction $action)
    {
        $this->authorize('update', $this->campaign);

        $this->validate([
            'extendForm.from_date' => 'required|date',
            'extendForm.to_date' => 'nullable|date|after_or_equal:extendForm.from_date',
            'extendForm.amount' => 'nullable|numeric|min:0',
            'extendForm.description' => 'required|string',
        ]);

        $action->execute($this->campaign, $this->extendForm);
        $this->closeExtendModal();
        $this->dispatch('campaign-extended');
    }

    public function openRenewModal()
    {
        $this->authorize('update', $this->campaign);

        $this->renewForm = [
            'starts_at' => now()->format('Y-m-d'),
            'from_date' => now()->format('Y-m-d'),
            'to_date' => null,
            'amount' => $this->campaign->monthly_fee,
            'description' => 'Rinnovo contratto',
        ];
        $this->showRenewModal = true;
    }

    public function closeRenewModal()
    {
        $this->showRenewModal = false;
    }

    public function renewCampaign(\App\Domain\Social\Actions\RenewMarketingCampaignAction $action)
    {
        $this->authorize('update', $this->campaign);

        $this->validate([
            'renewForm.starts_at' => 'nullable|date',
            'renewForm.from_date' => 'required|date',
            'renewForm.to_date' => 'nullable|date|after_or_equal:renewForm.from_date',
            'renewForm.amount' => 'nullable|numeric|min:0',
            'renewForm.description' => 'required|string',
        ]);

        $action->execute($this->campaign, $this->renewForm);
        $this->closeRenewModal();
        $this->dispatch('campaign-renewed');
    }

    public function openExtraModal()
    {
        $this->authorize('update', $this->campaign);
        $this->extraForm = [
            'description' => '',
            'amount' => null,
            'occurred_on' => now()->format('Y-m-d'),
        ];
        $this->showExtraModal = true;
    }

    public function closeExtraModal()
    {
        $this->showExtraModal = false;
    }

    public function addExtra(\App\Domain\Social\Actions\AddMarketingCampaignExtraAction $action)
    {
        $this->authorize('update', $this->campaign);

        $this->validate([
            'extraForm.description' => 'required|string',
            'extraForm.amount' => 'required|numeric|min:0',
            'extraForm.occurred_on' => 'nullable|date',
        ]);

        $action->execute($this->campaign, $this->extraForm);
        $this->closeExtraModal();
        $this->dispatch('campaign-extra-added');
    }

    public function deleteExtra(int $extraId, \App\Domain\Social\Actions\CancelMarketingCampaignExtraAction $action)
    {
        $this->authorize('update', $this->campaign);

        $extra = $this->campaign->extras()->findOrFail($extraId);

        try {
            $action->execute($extra);
            $this->dispatch('campaign-extra-deleted');
        } catch (\Exception $e) {
            Log::warning('Unable to cancel marketing campaign extra', [
                'campaign_id' => $this->campaign->id,
                'extra_id' => $extraId,
                'error' => $e->getMessage(),
            ]);
            $this->addError('extraForm', 'Non è stato possibile annullare questa voce. Riprova tra poco.');
        }
    }

    public function openInvoiceModal()
    {
        $this->authorize('update', $this->campaign);

        $pendingPeriods = $this->campaign->periods()->whereNull('invoice_id')->get();
        $pendingExtras = $this->campaign->extras()->whereNull('invoice_id')->where('status', \App\Enums\Social\MarketingCampaignExtraStatus::Pending)->get();

        $this->pendingPeriodsForInvoice = $pendingPeriods->map(fn($p) => ['id' => $p->id, 'description' => $p->description, 'amount' => $p->amount])->toArray();
        $this->pendingExtrasForInvoice = $pendingExtras->map(fn($e) => ['id' => $e->id, 'description' => $e->description, 'amount' => $e->amount])->toArray();

        $this->invoiceForm = [
            'number' => '',
            'issue_date' => now()->format('Y-m-d'),
            'due_date' => now()->addDays(30)->format('Y-m-d'),
            'vat_rate' => 22,
            'period_ids' => $pendingPeriods->pluck('id')->toArray(),
            'extra_ids' => $pendingExtras->pluck('id')->toArray(),
        ];

        $this->customLines = [
            ['description' => '', 'quantity' => 1, 'unit_price' => ''],
        ];

        $this->showInvoiceModal = true;
    }

    public function addCustomLine(): void
    {
        $this->customLines[] = ['description' => '', 'quantity' => 1, 'unit_price' => ''];
    }

    public function removeCustomLine(int $index): void
    {
        array_splice($this->customLines, $index, 1);
    }

    public function closeInvoiceModal()
    {
        $this->showInvoiceModal = false;
    }

    public function generateInvoice(\App\Domain\Social\Actions\GenerateMarketingCampaignInvoiceAction $action)
    {
        $this->authorize('update', $this->campaign);

        $this->validate([
            'invoiceForm.number' => 'required|string|unique:invoices,number',
            'invoiceForm.issue_date' => 'required|date',
            'invoiceForm.due_date' => 'nullable|date|after_or_equal:invoiceForm.issue_date',
            'invoiceForm.vat_rate' => 'required|numeric|min:0|max:100',
            'customLines.*.description' => 'nullable|string|max:255',
            'customLines.*.quantity'    => 'nullable|numeric|min:0.01',
            'customLines.*.unit_price'  => 'nullable|numeric|min:0',
        ]);

        $this->invoiceForm['custom_lines'] = array_values(
            array_filter($this->customLines, fn($l) => !empty($l['description']) && $l['unit_price'] !== '')
        );

        try {
            $action->execute($this->campaign, $this->invoiceForm);

            $this->campaign->refresh();
            $this->campaign->load(['periods', 'extras', 'invoices.items']);

            $this->closeInvoiceModal();
            $this->dispatch('campaign-invoice-generated');
        } catch (\Exception $e) {
            Log::error('Unable to generate marketing campaign invoice', [
                'campaign_id' => $this->campaign->id,
                'error' => $e->getMessage(),
            ]);
            $this->addError('invoiceForm', 'Non è stato possibile creare la fattura. Controlla i dati e riprova.');
        }
    }
    // ---------------------------------------------

    public function render()
    {
        $currentDate = \Carbon\Carbon::parse($this->calendarDate);

        $allPostsQuery = $this->campaign->posts()
            ->with(['currentVersion', 'currentVersion.mediaItems', 'mediaItems', 'publications']);

        if ($this->postFilter === 'archived') {
            $allPostsQuery->onlyArchived();
        } else {
            $allPostsQuery->notArchived();
        }

        $allPosts = $allPostsQuery
            ->orderByRaw('scheduled_date IS NULL')
            ->orderBy('scheduled_date', 'desc')
            ->orderBy('scheduled_time', 'desc')
            ->orderBy('created_at', 'desc')
            ->limit(20)
            ->get();

        $firstDayOfMonth = $currentDate->copy()->startOfMonth();
        $daysInMonth = $firstDayOfMonth->daysInMonth;
        $startDayOfWeek = $firstDayOfMonth->dayOfWeekIso;

        $days = [];
        for ($i = 1; $i < $startDayOfWeek; $i++) {
            $days[] = $firstDayOfMonth->copy()->subDays($startDayOfWeek - $i);
        }
        for ($i = 1; $i <= $daysInMonth; $i++) {
            $days[] = $firstDayOfMonth->copy()->addDays($i - 1);
        }
        $remaining = count($days) % 7;
        if ($remaining > 0) {
            $padding = 7 - $remaining;
            $lastDay = end($days);
            for ($i = 1; $i <= $padding; $i++) {
                $days[] = $lastDay->copy()->addDays($i);
            }
        }

        $prevMonth = $firstDayOfMonth->copy()->subMonth()->toDateString();
        $nextMonth = $firstDayOfMonth->copy()->addMonth()->toDateString();

        $resolvedPostPreviews = [];
        foreach ($allPosts as $post) {
            try {
                $resolution = $this->mediaResolver->resolveForPost($post);
                $resolvedPostPreviews[$post->id] = $this->urlResolver->primaryPreviewUrlOrNull($resolution->mediaItems);
            } catch (MarketingCampaignPostMediaResolutionException $exception) {
                Log::warning('social.version_media.preview_resolution_failed', [
                    'marketing_campaign_post_id' => $post->id,
                    'error' => $exception->getMessage(),
                ]);
                $resolvedPostPreviews[$post->id] = null;
            }
        }

        return view('livewire.social.marketing-campaigns.marketing-campaign-show', [
            'posts' => $allPosts,
            'resolvedPostPreviews' => $resolvedPostPreviews,
            'totalPostsCount' => $this->campaign->posts()->notArchived()->count(),
            'archivedPostsCount' => $this->campaign->posts()->onlyArchived()->count(),
            'currentDate' => $currentDate,
            'days' => $days,
            'prevMonth' => $prevMonth,
            'nextMonth' => $nextMonth,
            'monthName' => $firstDayOfMonth->translatedFormat('F Y'),
            'publishedDates' => $this->publishedDates(),
        ])->layout('layouts.app', ['title' => $this->campaign->name]);
    }

}
