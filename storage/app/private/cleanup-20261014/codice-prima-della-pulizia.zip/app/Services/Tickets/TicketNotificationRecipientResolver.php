<?php

namespace App\Services\Tickets;

use App\Enums\UserRole;
use App\Models\Ticket;
use App\Models\User;
use Illuminate\Support\Collection;

class TicketNotificationRecipientResolver
{
    public function admins(): Collection
    {
        return User::query()
            ->where('role', UserRole::Admin->value)
            ->where('status', 'active')
            ->get();
    }

    public function recipientsFor(Ticket $ticket): Collection
    {
        $recipients = $this->admins();

        if ($ticket->assignee && $ticket->assignee->status === 'active') {
            $recipients->push($ticket->assignee);
        }

        $recipients = $recipients->unique('id');

        if (auth()->check()) {
            $recipients = $recipients->reject(fn($user) => $user->id === auth()->id());
        }

        return $recipients->values();
    }

    public function intakeRecipients(Ticket $ticket): Collection
    {
        return User::query()->where('status', 'active')
            ->whereIn('role', $ticket->type === 'quote'
                ? [UserRole::Admin->value, UserRole::Administration->value]
                : [UserRole::Admin->value])->get();
    }
}
