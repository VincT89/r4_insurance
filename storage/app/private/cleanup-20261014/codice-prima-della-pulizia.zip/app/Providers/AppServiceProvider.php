<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

use Illuminate\Support\Facades\Gate;
use App\Models\{Ticket, Invoice, Payment, CalendarEvent, Client, Project, Task, Attachment, UserAvailability};
use App\Policies\{TicketPolicy, InvoicePolicy, PaymentPolicy, CalendarEventPolicy,
                  ClientPolicy, ProjectPolicy, TaskPolicy, AttachmentPolicy, UserAvailabilityPolicy};
use App\Observers\{TicketObserver, InvoiceObserver, PaymentObserver, CalendarEventObserver, ClientObserver, ProjectObserver, TaskObserver, AttachmentObserver, UserObserver};

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
    }


    public function boot(): void
    {
        Gate::before(function (\App\Models\User $user, string $ability, array $arguments) {
            if (!$user->isCommercial()) {
                return null;
            }
            $subject = $arguments[0] ?? null;
            if ((is_object($subject) || is_string($subject)) && is_a($subject, Client::class, true)
                && in_array($ability, ['lookup', 'quickCreate', 'selectForTicket', 'viewAny', 'view', 'create', 'updateRegistry', 'viewMaterials', 'manageMaterials'], true)) {
                return null;
            }
            foreach ([Task::class, \App\Models\Quote::class] as $readable) {
                if ((is_object($subject) || is_string($subject)) && is_a($subject, $readable, true)
                    && in_array($ability, ['viewAny', 'view'], true)) {
                    return null;
                }
            }
            foreach ([Ticket::class, Attachment::class, UserAvailability::class, CalendarEvent::class] as $allowed) {
                if ((is_object($subject) || is_string($subject)) && is_a($subject, $allowed, true)) {
                    return null;
                }
            }
            return false;
        });

        \Carbon\Carbon::setLocale('it');
        \Illuminate\Pagination\Paginator::defaultView('vendor.pagination.custom');
        \Illuminate\Support\Facades\Blade::anonymousComponentPath(resource_path('views/layouts'), 'layouts');

        \Illuminate\Support\Facades\RateLimiter::for('nextcloud-preview', function (\Illuminate\Http\Request $request) {
            return \Illuminate\Cache\RateLimiting\Limit::perMinute(120)->by($request->user()?->id ?: $request->ip());
        });

        \Illuminate\Support\Facades\RateLimiter::for('aruba-callbacks', function (\Illuminate\Http\Request $request) {
            return \Illuminate\Cache\RateLimiting\Limit::perMinute(120)->by($request->ip());
        });

        \Illuminate\Support\Facades\RateLimiter::for('social-media-delivery', function (\Illuminate\Http\Request $request) {
            // Seleziona la chiave: dal media object se esiste, altrimenti dal combination publication+index
            $media = $request->route('media');
            $mediaId = is_object($media) ? $media->getKey() : $media;
            
            if (!$mediaId) {
                $pubId = $request->route('publication');
                $mediaIndex = $request->route('mediaIndex');
                $mediaId = "pub_{$pubId}_index_{$mediaIndex}";
            }

            return \Illuminate\Cache\RateLimiting\Limit::perMinute(300)->by(
                $mediaId.'|'.$request->ip()
            )->response(function (\Illuminate\Http\Request $request, array $headers) use ($mediaId) {
                \Illuminate\Support\Facades\Log::warning('Rate limit superato per Provider Delivery', [
                    'media_identifier' => $mediaId,
                    'ip' => $request->ip()
                ]);
                return response('Too Many Requests', 429, $headers);
            });
        });

        Gate::policy(Ticket::class,        TicketPolicy::class);
        Gate::policy(Invoice::class,       InvoicePolicy::class);
        Gate::policy(Payment::class,       PaymentPolicy::class);
        Gate::policy(CalendarEvent::class, CalendarEventPolicy::class);
        Gate::policy(Client::class,        ClientPolicy::class);
        Gate::policy(Project::class,       ProjectPolicy::class);
        Gate::policy(Task::class,          TaskPolicy::class);
        Gate::policy(\App\Models\Quote::class, \App\Policies\QuotePolicy::class);
        Gate::policy(Attachment::class,    AttachmentPolicy::class);
        Gate::policy(UserAvailability::class, UserAvailabilityPolicy::class);
        Gate::policy(\App\Models\HostingService::class, \App\Policies\HostingServicePolicy::class);
        Gate::policy(\App\Models\Expense::class, \App\Policies\ExpensePolicy::class);
        Gate::policy(\App\Models\Team::class, \App\Policies\TeamPolicy::class);
        Gate::policy(\App\Models\ClientSocialAccount::class, \App\Policies\ClientSocialAccountPolicy::class);

        // Shooting Policies
        Gate::policy(\App\Models\Shooting\Shoot::class, \App\Policies\ShootPolicy::class);

        // Marketing Campaign Policies
        Gate::policy(\App\Models\MarketingCampaign::class, \App\Policies\MarketingCampaignPolicy::class);
        Gate::policy(\App\Models\MarketingCampaignPost::class, \App\Policies\MarketingCampaignPostPolicy::class);

        Gate::define('system.admin', function (\App\Models\User $user) {
            return $user->canManageSystem();
        });

        Gate::define('manage_social_connections', function (\App\Models\User $user) {
            return $user->canManageSystem();
        });

        Gate::define('manage_social_operations', function (\App\Models\User $user) {
            return $user->canManageMarketing();
        });
        Gate::define('view_social_connections', fn (\App\Models\User $user) => $user->canManageSystem() || $user->isAdministration());
        Gate::define('view_social_operations', fn (\App\Models\User $user) => $user->canViewManagementDashboard() || $user->canManageMarketing());

        \Illuminate\Support\Facades\View::composer('layouts.app', function ($view) {
            if (auth()->check()) {
                $user = auth()->user();

                if ($user->isCommercial()) {
                    $view->with([
                        'clientsCount' => Client::visibleTo($user)->count(), 'projectsCount' => 0, 'overdueInvoices' => 0,
                        'openTasks' => Task::query()->open()->count(), 'marketingProjectsCount' => 0,
                        'activeAvailabilityUsersCount' => 0, 'newTickets' => 0,
                        'openTickets' => Ticket::query()->open()->count(),
                        'unreadNotificationsCount' => $user->visibleNotifications()->whereNull('read_at')->count(),
                        'latestNotifications' => $user->visibleNotifications()->latest()->limit(5)->get(),
                    ]);
                    return;
                }

                $counts = \Illuminate\Support\Facades\Cache::remember('sidebar_counts_' . $user->id, 60, function () use ($user) {
                    return [
                        'clientsCount'    => \App\Models\Client::visibleTo($user)->where('status', 'active')->count(),
                        'projectsCount'   => \App\Models\Project::visibleTo($user)->where('status', 'active')->count(),
                        'openTickets'     => \App\Models\Ticket::visibleTo($user)->whereIn('status', ['open', 'in_progress'])->count(),
                        'overdueInvoices' => \App\Models\Invoice::visibleTo($user)->where('status', 'overdue')->count(),
                        'openTasks'       => \App\Models\Task::visibleTo($user)->open()->count(),
                        'marketingProjectsCount' => \App\Models\MarketingCampaign::visibleTo($user)->whereIn('status', ['draft', 'active'])->count(),
                    ];
                });

                $activeAvailabilityUsersCount = 0;
                if ($user->canManageSystem()) {
                    $activeAvailabilityUsersCount = UserAvailability::query()
                        ->activeAt(now())
                        ->whereHas('user', fn ($query) => $query->where('status', 'active'))
                        ->distinct()
                        ->count('user_id');
                }

                $newTickets = 0;
                if ($user->can('viewAny', \App\Models\Ticket::class)) {
                    $ticketQuery = \App\Models\Ticket::whereNotIn('status', ['resolved', 'closed'])
                        ->where(function ($query) use ($user) {
                            $query->where('created_by', '!=', $user->id)
                                  ->orWhereNull('created_by');
                        })
                        ->where('created_at', '>', $user->last_tickets_viewed_at ?? now()->subYears(10));

                    $ticketQuery->visibleTo($user);

                    $newTickets = $ticketQuery->count();
                }

                $view->with([
                    'clientsCount'    => $counts['clientsCount'],
                    'projectsCount'   => $counts['projectsCount'],
                    'openTickets'     => $counts['openTickets'],
                    'overdueInvoices' => $counts['overdueInvoices'],
                    'openTasks'       => $counts['openTasks'],
                    'marketingProjectsCount' => $counts['marketingProjectsCount'],
                    'activeAvailabilityUsersCount' => $activeAvailabilityUsersCount,
                    'newTickets'      => $newTickets,
                    'unreadNotificationsCount' => $user->unreadNotifications()->count(),
                    'latestNotifications'      => $user->notifications()->latest()->limit(5)->get(),
                ]);
            }
        });
    }
}
