<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\Builder;
use App\Models\User;

class Ticket extends Model
{
    use \Illuminate\Database\Eloquent\Factories\HasFactory;

    protected static function booted()
    {
        static::addGlobalScope(new \App\Models\Scopes\ProjectSupremacyScope);

        static::deleting(function ($ticket) {
            $ticket->attachments->each(fn($attachment) => $attachment->delete());
            $ticket->comments()->delete();
        });
    }

    public const TYPES = [
        'support',
        'bug',
        'request',
        'change',
        'admin',
        'quote',
    ];

    public const DEPARTMENTS = [
        'developer' => 'Sviluppo',
        'marketing' => 'Marketing',
        'graphic_designer' => 'Grafica',
        'photographer' => 'Fotografia',
        'administration' => 'Amministrazione',
        'other' => 'Altro',
    ];

    public const STATUSES = [
        'open',
        'in_progress',
        'waiting',
        'resolved',
        'closed',
    ];

    public const PRIORITIES = [
        'low',
        'medium',
        'high',
        'urgent',
    ];

    protected $fillable = [
        'client_id',
        'project_id',
        'created_by',
        'assigned_to',
        'code',
        'title',
        'description',
        'type',
        'status',
        'priority',
        'opened_at',
        'due_date',
        'closed_at',
        'resolution_notes',
        'notes',
        'external_id',
        'source',
        'context',
        'received_at',
        'requested_department',
    ];

    protected $casts = [
        'opened_at' => 'datetime',
        'due_date' => 'date',
        'closed_at' => 'datetime',
        'context' => 'array',
        'received_at' => 'datetime',
    ];

        public function getPriorityLabelAttribute(): string
    {
        return match ($this->priority) {
            'low' => 'Bassa',
            'medium' => 'Media',
            'high' => 'Alta',
            'urgent' => 'Urgente',
            default => ucfirst((string) $this->priority),
        };
    }

    public function getTypeLabelAttribute(): string
    {
        return match ($this->type) {
            'support' => 'Supporto',
            'bug' => 'Bug',
            'request' => 'Richiesta',
            'change' => 'Modifica',
            'admin' => 'Amministrazione commerciale',
            'quote' => 'Richiesta di preventivo',
            default => ucfirst((string) $this->type),
        };
    }

    public function getStatusLabelAttribute(): string
    {
        return match ($this->status) {
            'open' => 'Aperto',
            'in_progress' => 'In lavorazione',
            'waiting' => 'In attesa',
            'resolved' => 'Risolto',
            'closed' => 'Chiuso',
            default => ucfirst((string) $this->status),
        };
    }

    public function client(): BelongsTo
    {
        return $this->belongsTo(Client::class);
    }

    public function project(): BelongsTo
    {
        $relation = $this->belongsTo(Project::class);

        // Il commerciale legge solo il nome del progetto del proprio ticket.
        if (auth()->user()?->isCommercial()) {
            $relation->withoutGlobalScope(\App\Models\Scopes\ProjectSupremacyScope::class)
                ->select(['projects.id', 'projects.name', 'projects.client_id']);
        }

        return $relation;
    }

    public function tasks()
    {
        return $this->hasMany(Task::class);
    }

    public function requestedServices()
    {
        return $this->hasMany(TicketRequestedService::class)->orderBy('sort_order');
    }

    public function quotes()
    {
        return $this->hasMany(Quote::class);
    }

    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function assignee(): BelongsTo
    {
        return $this->belongsTo(User::class, 'assigned_to');
    }

    public function attachments(): MorphMany
    {
        return $this->morphMany(Attachment::class, 'attachable');
    }

    public function expenses(): MorphMany
    {
        return $this->morphMany(Expense::class, 'expenseable');
    }

    public function auditLogs(): MorphMany
    {
        return $this->morphMany(AuditLog::class, 'auditable');
    }



    public function comments()
    {
        return $this->hasMany(TicketComment::class)->latest();
    }

    public function checklistItems()
    {
        return $this->hasMany(TicketChecklistItem::class)->orderBy('sort_order');
    }

    public function scopeAssignedTo($query, $userOrId)
    {
        $id = $userOrId instanceof User ? $userOrId->id : $userOrId;
        return $query->where('assigned_to', $id);
    }

    public function scopeOpen($query)
    {
        return $query->whereNotIn('status', ['resolved', 'closed']);
    }

    public function scopeDueSoon($query, int $days = 7)
    {
        return $query->whereNotNull('due_date')
                     ->whereDate('due_date', '>=', today())
                     ->whereDate('due_date', '<=', today()->addDays($days));
    }

    public function scopeOverdue($query)
    {
        return $query->whereNotNull('due_date')
                     ->whereDate('due_date', '<', today())
                     ->whereNotIn('status', ['resolved', 'closed']);
    }

    public function scopeVisibleTo(Builder $query, User $user): Builder
    {
        if ($user->isCommercial()) {
            return $query->where('tickets.created_by', $user->id);
        }

        if ($user->canAccessAllProjects() || $user->canManageMarketing()) {
            return $query;
        }

        return $query->where(function ($visible) use ($user) {
            $visible->whereHas('project.users', fn ($members) => $members->where('users.id', $user->id))
                ->orWhere(fn ($unlinked) => $unlinked->whereNull('project_id')->where('assigned_to', $user->id));
        });
    }
}
