<?php

namespace App\Http\Controllers;

use App\Models\Client;
use App\Models\Project;
use App\Models\Task;
use App\Models\Ticket;
use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use App\Http\Requests\StoreTaskRequest;
use App\Http\Requests\UpdateTaskRequest;
use Illuminate\View\View;

class TaskController extends Controller
{

    public const STATUSES   = ['todo', 'in_progress', 'waiting', 'done'];
    public const PRIORITIES = ['low', 'medium', 'high', 'urgent'];

    public function index(Request $request, \App\Domain\Core\Queries\TaskQuery $taskQuery): View
    {
        $this->authorize('viewAny', Task::class);

        if ($request->user()->isCommercial()) {
            $query = $taskQuery->forIndex($request->all())->with('commercialShoot');
            if ($request->filled('client_id')) {
                $query->forClients([$request->integer('client_id')]);
            }
            return view('tasks.commercial.index', [
                'tasks' => $query->paginate(20)->withQueryString(),
                'clients' => Client::visibleTo($request->user())->orderBy('name')->get(['id', 'name']),
            ]);
        }

        $viewMode = $request->get('view') === 'kanban' ? 'kanban' : 'list';
        
        $taskList = null;
        $kanbanTasks = null;

        if ($viewMode === 'kanban') {
            $kanbanTasks = $taskQuery->forKanban($request->all())->get();
        } else {
            $taskList = $taskQuery->forIndex($request->all())->paginate(20)->withQueryString();
        }

        $projects = Project::where('status', 'active')->orderBy('name')->get(['id', 'name']);
        $users    = User::where('status', 'active')->orderBy('name')->get(['id', 'name']);

        return view('tasks.index', compact('viewMode', 'taskList', 'kanbanTasks', 'projects', 'users'));
    }

    public function create(Request $request): View
    {
        $this->authorize('create', Task::class);

        $projects = Project::with('client')->where('status', 'active')->orderBy('name')->get();
        $users = $this->taskAssignees();

        // Precompila l'ID progetto se fornito via querystring
        $preselectedProjectId = $request->project_id;

        if (empty($preselectedProjectId)) {
            $preselectedProjectId = \App\Models\Project::where('slug', 'progetto-interno')
                ->where('status', 'active')
                ->value('id');
        }

        $sourceTicket = null;
        if ($request->filled('ticket_id')) {
            $sourceTicket = Ticket::with(['project', 'client'])->findOrFail($request->ticket_id);
            $this->authorize('view', $sourceTicket);
        }

        return view('tasks.create', [
            'projects'            => $projects,
            'users'               => $users,
            'statuses'            => self::STATUSES,
            'priorities'          => self::PRIORITIES,
            'preselectedProjectId'=> $preselectedProjectId,
            'sourceTicket'        => $sourceTicket,
        ]);
    }

    public function store(StoreTaskRequest $request, \App\Domain\Core\Actions\CreateTaskAction $action): RedirectResponse
    {
        $data = $request->validated();

        $data['created_by'] = auth()->id();

        if ($data['status'] === 'done') {
            $data['completed_at'] = now();
        }

        $task = $action->execute($data);

        if ($task->ticket && $task->ticket->status === 'open') {
            $task->ticket->update(['status' => 'in_progress']);
        }

        return redirect()->route('tasks.index')
            ->with('success', 'Task creato correttamente.');
    }

    public function show(Task $task, \App\Domain\Core\Queries\TaskQuery $taskQuery): View
    {
        $this->authorize('view', $task);
        if (auth()->user()->isCommercial()) {
            $task->load(['project.client:id,name', 'assignee:id,name', 'ticket:id,title,code,client_id,created_by', 'commercialShoot']);
            return view('tasks.commercial.show', compact('task'));
        }
        $task->load([
            'project.client', 
            'creator', 
            'assignee', 
            'attachments', 
            'comments.user',
            'checklistItems.completedBy',
        ]);
        if (auth()->user()->canViewAuditLogs()) {
            $task->load(['auditLogs' => fn ($q) => $q->with('user')->latest()->limit(8)]);
        }

        $projectTasks = collect();

        if ($task->project_id) {
            $projectTasks = $taskQuery->forSidebar($task->project_id)->get();
        }

        return view('tasks.show', compact('task', 'projectTasks'));
    }

    public function edit(Task $task): View
    {
        $this->authorize('update', $task);

        $projects = Project::with('client')->where('status', 'active')->orderBy('name')->get();
        $users = $this->taskAssignees($task);

        return view('tasks.edit', [
            'task'       => $task,
            'projects'   => $projects,
            'users'      => $users,
            'statuses'   => self::STATUSES,
            'priorities' => self::PRIORITIES,
        ]);
    }

    public function update(UpdateTaskRequest $request, Task $task, \App\Domain\Core\Actions\UpdateTaskAction $action): RedirectResponse
    {
        $data = $request->validated();

        // Imposta la data di completamento se il task viene chiuso
        if ($data['status'] === 'done' && !$task->completed_at) {
            $data['completed_at'] = now();
        } elseif ($data['status'] !== 'done') {
            $data['completed_at'] = null;
        }

        $action->execute($task, $data);

        return redirect()->route('tasks.show', $task)
            ->with('success', 'Task aggiornato correttamente.');
    }

    public function destroy(Task $task): RedirectResponse
    {
        $this->authorize('delete', $task);
        $projectId = $task->project_id;
        $task->delete();

        return redirect()->route('tasks.index')
            ->with('success', 'Task eliminato correttamente.');
    }


    public function updateStatus(Request $request, Task $task): RedirectResponse
    {
        $this->authorize('update', $task);

        $data = $request->validate([
            'status' => ['required', 'in:' . implode(',', self::STATUSES)],
        ]);

        if ($data['status'] === 'done' && !$task->completed_at) {
            $data['completed_at'] = now();
        } elseif ($data['status'] !== 'done') {
            $data['completed_at'] = null;
        }

        $task->update($data);

        if ($request->wantsJson()) {
            return response()->json(['success' => true, 'status' => $task->status]);
        }

        return redirect()->back()->with('success', 'Stato task aggiornato!');
    }

    private function taskAssignees(?Task $task = null): \Illuminate\Database\Eloquent\Collection
    {
        $users = User::where('status', 'active')->with('projects:id')->orderBy('name')->get()
            ->filter(fn (User $user) => $user->can('viewAny', Task::class));

        // Mostra un'eventuale assegnazione precedente non più valida, senza rimuoverla in silenzio.
        if ($task?->assigned_to && !$users->contains('id', $task->assigned_to)) {
            $currentAssignee = $task->assignee()->with('projects:id')->first();
            if ($currentAssignee) {
                $users->push($currentAssignee);
            }
        }

        return $users->sortBy('name')->values();
    }
}
