<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreTicketRequest;
use App\Http\Requests\UpdateTicketRequest;
use App\Models\Client;
use App\Models\Scopes\ProjectSupremacyScope;
use App\Enums\UserRole;
use App\Models\Ticket;
use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\View\View;
class TicketController extends Controller
{
    public function index(\Illuminate\Http\Request $request, \App\Domain\Core\Queries\TicketQuery $ticketQuery): View
    {
        $this->authorize('viewAny', Ticket::class);

        $user = auth()->user();
        $user->update(['last_tickets_viewed_at' => now()]);
        \Illuminate\Support\Facades\Cache::forget('sidebar_counts_' . $user->id);
        
        $tickets = $ticketQuery->forIndex($request->all())->paginate(15)->withQueryString();

        return view($user->isCommercial() ? 'tickets.commercial.index' : 'tickets.index', compact('tickets'));
    }

    public function create(\App\Domain\Core\Queries\ClientQuery $clientQuery): View
    {
        $this->authorize('create', Ticket::class);
        $clients = $clientQuery->forDropdown()->get(['id', 'name', 'company_name']);

        $users = auth()->user()->isCommercial() ? collect() : $this->ticketAssignees();

        return view('tickets.create', [
            'clients' => $clients,
            'users' => $users,
            'types' => Ticket::TYPES,
            'statuses' => Ticket::STATUSES,
            'priorities' => Ticket::PRIORITIES,
        ]);
    }

    public function store(StoreTicketRequest $request, \App\Domain\Core\Actions\CreateTicketAction $action): RedirectResponse
    {
        $ticket = $action->execute($request->validated());

        if ($request->user()->isCommercial()) {
            return redirect()->route('tickets.show', $ticket)->with('success', 'Ticket inviato all’amministratore.');
        }

        return redirect()
            ->route('tickets.index')
            ->with('success', 'Ticket creato correttamente.');
    }

    public function show(Ticket $ticket): View
    {
        $this->authorize('view', $ticket);
        $relations = [
            auth()->user()->isCommercial() ? 'client:id,name' : 'client',
            'project', 
            'creator:id,name,role',
            'assignee:id,name,role',
            'attachments.uploader', 
            'comments.user',
            'requestedServices',
        ];
        if (!auth()->user()->isCommercial()) {
            $relations = array_merge($relations, ['tasks.project', 'tasks.assignee', 'checklistItems.completedBy']);
        }
        if (auth()->user()->canViewAuditLogs()) {
            $relations[] = 'auditLogs.user';
        }
        $ticket->load($relations);
        $quotes = $ticket->quotes()->visibleTo(auth()->user())->commercialOrder()->get();
        return view(auth()->user()->isCommercial() ? 'tickets.commercial.show' : 'tickets.show', compact('ticket', 'quotes'));
    }

    public function edit(Ticket $ticket, \App\Domain\Core\Queries\ClientQuery $clientQuery): View
    {
        $this->authorize('update', $ticket);
        $clients = $clientQuery->forDropdown()->get();

        $users = $this->ticketAssignees($ticket);

        return view('tickets.edit', [
            'ticket' => $ticket->load(['client', 'project']),
            'clients' => $clients,
            'users' => $users,
            'types' => Ticket::TYPES,
            'statuses' => Ticket::STATUSES,
            'priorities' => Ticket::PRIORITIES,
        ]);
    }

    public function update(UpdateTicketRequest $request, Ticket $ticket): RedirectResponse
    {
        $this->authorize('update', $ticket);
        $data = $request->safe()->except(['assignment_department', 'requested_services']);

        if (($data['status'] ?? null) === 'closed') {
            $data['closed_at'] = $ticket->closed_at ?? now();
        } else {
            $data['closed_at'] = null;
        }

        if (empty($ticket->opened_at) && empty($data['opened_at'])) {
            $data['opened_at'] = now();
        }

        $oldAssignedTo = $ticket->assigned_to;
        \Illuminate\Support\Facades\DB::transaction(function () use ($ticket, $data, $request) {
            $ticket->update($data);
            if ($ticket->type === 'quote' && $request->has('requested_services')) {
                $ticket->requestedServices()->delete();
                foreach (array_values($request->validated('requested_services', [])) as $index => $service) {
                    $ticket->requestedServices()->create($service + ['sort_order' => $index]);
                }
            }
        });

        if (
            !empty($data['assigned_to']) &&
            (int) $data['assigned_to'] !== (int) $oldAssignedTo
        ) {
            event(new \App\Domain\Core\Events\TicketAssigned($ticket));
        }

        return redirect()
            ->route('tickets.show', $ticket)
            ->with('success', 'Ticket aggiornato correttamente.');
    }

    public function updateStatus(\Illuminate\Http\Request $request, Ticket $ticket): RedirectResponse
    {
        $this->authorize('update', $ticket);

        $validated = $request->validate([
            'status' => ['required', 'string', \Illuminate\Validation\Rule::in(Ticket::STATUSES)],
        ]);

        if ($validated['status'] === 'closed') {
            $validated['closed_at'] = $ticket->closed_at ?? now();
        } else {
            $validated['closed_at'] = null;
        }

        $ticket->update($validated);

        return redirect()->back()->with('success', 'Stato aggiornato.');
    }

    public function destroy(Ticket $ticket): RedirectResponse
    {
        $this->authorize('delete', $ticket);
        $ticket->delete();

        return redirect()
            ->route('tickets.index')
            ->with('success', 'Ticket eliminato correttamente.');
    }

    public function clientProjects(Client $client): \Illuminate\Http\JsonResponse
    {
        $this->authorize('create', Ticket::class);
        $this->authorize('selectForTicket', $client);
        $projects = $client->projects();
        if (auth()->user()->isCommercial()) {
            $projects->withoutGlobalScope(ProjectSupremacyScope::class);
        }
        return response()->json($projects->where('status', 'active')->orderBy('name')->get(['id', 'name']));
    }

    private function ticketAssignees(?Ticket $ticket = null)
    {
        return User::query()->where(function ($query) use ($ticket) {
            $query->where(function ($eligible) {
                $eligible->where('status', 'active')->whereIn('role', [
                    UserRole::Admin, UserRole::Administration, UserRole::Developer, UserRole::GraphicDesigner, UserRole::OperationsManager,
                ]);
            });
            if ($ticket?->assigned_to) {
                $query->orWhere('id', $ticket->assigned_to);
            }
        })->with('projects:id')->orderBy('name')->get(['id', 'name', 'role', 'status']);
    }
}
