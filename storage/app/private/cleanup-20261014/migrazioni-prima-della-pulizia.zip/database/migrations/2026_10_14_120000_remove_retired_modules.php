<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public $withinTransaction = false;

    private const TABLES = [
        'marketing_campaign_post_version_media',
        'marketing_campaign_post_publications',
        'marketing_campaign_post_media',
        'marketing_campaign_post_comments',
        'marketing_campaign_post_versions',
        'marketing_campaign_posts',
        'marketing_campaign_extras',
        'marketing_campaign_periods',
        'client_review_tokens',
        'temporary_media_uploads',
        'marketing_campaigns',
        'agency_social_assets',
        'agency_social_connections',
        'client_social_accounts',
        'shoot_slots',
        'shoots',
        'chatbot_client_sessions',
        'chatbot_marketing_posts',
        'chatbot_marketing_campaigns',
        'chatbot_tickets',
        'chatbot_projects',
        'chatbot_clients',
        'ticket_checklist_items',
        'ticket_comments',
        'ticket_requested_services',
        'tickets',
        'task_checklist_items',
        'task_comments',
        'tasks',
        'hosting_service_interventions',
        'hosting_services',
        'electronic_invoice_events',
        'electronic_invoice_transmissions',
        'payments',
        'invoice_items',
        'invoices',
        'invoice_number_sequences',
        'expense_documents',
        'expenses',
        'expense_recurrences',
        'manual_incomes',
        'cash_flow_settings',
        'billing_profiles',
        'quote_items',
        'quotes',
        'quote_services',
        'calendar_events',
        'user_availabilities',
        'project_user',
        'projects',
    ];
    private const RETIRED_MODELS = [
        'App\\Models\\AgencySocialAsset',
        'App\\Models\\AgencySocialConnection',
        'App\\Models\\BillingProfile',
        'App\\Models\\CalendarEvent',
        'App\\Models\\CashFlowSetting',
        'App\\Models\\Chatbot\\ChatbotClient',
        'App\\Models\\Chatbot\\ChatbotMarketingCampaign',
        'App\\Models\\Chatbot\\ChatbotMarketingPost',
        'App\\Models\\Chatbot\\ChatbotProject',
        'App\\Models\\Chatbot\\ChatbotTicket',
        'App\\Models\\ChatbotClientSession',
        'App\\Models\\ClientReviewToken',
        'App\\Models\\ClientSocialAccount',
        'App\\Models\\ElectronicInvoiceEvent',
        'App\\Models\\ElectronicInvoiceTransmission',
        'App\\Models\\Expense',
        'App\\Models\\ExpenseDocument',
        'App\\Models\\ExpenseRecurrence',
        'App\\Models\\HostingService',
        'App\\Models\\HostingServiceIntervention',
        'App\\Models\\Invoice',
        'App\\Models\\InvoiceItem',
        'App\\Models\\InvoiceNumberSequence',
        'App\\Models\\ManualIncome',
        'App\\Models\\MarketingCampaign',
        'App\\Models\\MarketingCampaignExtra',
        'App\\Models\\MarketingCampaignPeriod',
        'App\\Models\\MarketingCampaignPost',
        'App\\Models\\MarketingCampaignPostComment',
        'App\\Models\\MarketingCampaignPostMedia',
        'App\\Models\\MarketingCampaignPostPublication',
        'App\\Models\\MarketingCampaignPostVersion',
        'App\\Models\\Payment',
        'App\\Models\\Project',
        'App\\Models\\Quote',
        'App\\Models\\QuoteItem',
        'App\\Models\\QuoteService',
        'App\\Models\\Scopes\\ProjectSupremacyScope',
        'App\\Models\\Scopes\\UserScopedShootScope',
        'App\\Models\\Shooting\\Shoot',
        'App\\Models\\Shooting\\ShootSlot',
        'App\\Models\\Task',
        'App\\Models\\TaskChecklistItem',
        'App\\Models\\TaskComment',
        'App\\Models\\TemporaryMediaUpload',
        'App\\Models\\Ticket',
        'App\\Models\\TicketChecklistItem',
        'App\\Models\\TicketComment',
        'App\\Models\\TicketRequestedService',
        'App\\Models\\UserAvailability',
    ];
    private const RETIRED_NOTIFICATIONS = [
        'App\\Notifications\\ChatbotClientInteractionNotification',
        'App\\Notifications\\ElectronicInvoiceStatusNotification',
        'App\\Notifications\\InvoiceOverdueNotification',
        'App\\Notifications\\PaymentRecordedNotification',
        'App\\Notifications\\QuoteUpdatedNotification',
        'App\\Notifications\\ShootingWorkflowNotification',
        'App\\Notifications\\TaskAssignedNotification',
        'App\\Notifications\\TaskCreatedAdminNotification',
        'App\\Notifications\\TaskDueSoonNotification',
        'App\\Notifications\\TicketAssignedNotification',
        'App\\Notifications\\TicketDueSoonNotification',
        'App\\Notifications\\TicketOverdueNotification',
        'App\\Notifications\\TicketUnassignedNotification',
    ];
    private const RETIRED_JOBS = [
        'App\\Jobs\\Chatbot\\SyncChatbotClientDataJob',
        'App\\Jobs\\RequestMarketingCampaignPostRegenerationJob',
        'App\\Jobs\\SendMarketingCampaignPostToN8nJob',
        'App\\Jobs\\Social\\CheckInstagramContainerStatusJob',
        'App\\Jobs\\Social\\CheckSocialAccountStatusJob',
        'App\\Jobs\\Social\\ExecuteMarketingCampaignPostPublicationJob',
        'App\\Jobs\\Social\\PublishMarketingCampaignPostJob',
        'App\\Jobs\\Social\\TikTok\\CheckTikTokPostStatusJob',
    ];

    public function up(): void
    {
        // All preflight checks precede writes. MySQL DDL cannot be rolled back.
        $existing = array_values(array_filter(self::TABLES, fn ($name) => Schema::hasTable($name)));
        foreach (Schema::getTables() as $table) {
            $name = $table['name'];
            if (in_array($name, $existing, true)) {
                continue;
            }
            foreach (Schema::getForeignKeys($name) as $foreign) {
                if (in_array($foreign['foreign_table'], $existing, true)) {
                    throw new RuntimeException("Pulizia interrotta: $name dipende da {$foreign['foreign_table']}. Verificare la relazione prima di procedere.");
                }
            }
        }
        $hasData = false;
        foreach ($existing as $name) {
            $hasData = $hasData || DB::table($name)->exists();
        }
        $hasData = $hasData || DB::table('attachments')->whereIn('attachable_type', self::RETIRED_MODELS)->exists();
        if (Schema::hasTable('notifications')) {
            $hasData = $hasData || DB::table('notifications')->whereIn('type', self::RETIRED_NOTIFICATIONS)->exists();
        }
        if (Schema::hasColumn('clients', 'nextcloud_folder_name')) {
            $hasData = $hasData || DB::table('clients')->whereNotNull('nextcloud_folder_name')->exists();
        }
        if ($hasData && config('module-cleanup.backup_confirmed') !== true) {
            throw new RuntimeException('Pulizia interrotta prima delle modifiche: sono presenti dati nei moduli da eliminare. Salvare e verificare il backup del database e dei file, poi impostare MODULE_CLEANUP_BACKUP_CONFIRMED=true e rigenerare la configurazione.');
        }

        if (! Schema::hasTable('client_user')) {
            Schema::create('client_user', function (Blueprint $table) {
                $table->id();
                $table->foreignId('client_id')->constrained()->cascadeOnDelete();
                $table->foreignId('user_id')->constrained()->cascadeOnDelete();
                $table->timestamps();
                $table->unique(['client_id', 'user_id']);
            });
        }
        if (! Schema::hasTable('module_cleanup_attachment_archive')) {
            Schema::create('module_cleanup_attachment_archive', function (Blueprint $table) {
                $table->unsignedBigInteger('attachment_id')->primary();
                $table->longText('metadata');
                $table->timestamp('archived_at');
            });
        }
        DB::transaction(function () {
            if (Schema::hasTable('projects') && Schema::hasTable('project_user')) {
                DB::table('project_user')->join('projects', 'projects.id', '=', 'project_user.project_id')
                    ->whereNotNull('projects.client_id')
                    ->select('project_user.id', 'projects.client_id', 'project_user.user_id')
                    ->chunkById(200, function ($rows) {
                        foreach ($rows as $row) {
                            DB::table('client_user')->insertOrIgnore([
                                'client_id' => $row->client_id, 'user_id' => $row->user_id,
                                'created_at' => now(), 'updated_at' => now(),
                            ]);
                        }
                    }, 'project_user.id', 'id');
            }
            // Archive metadata without running model observers or deleting files on disk.
            DB::table('attachments')->whereIn('attachable_type', self::RETIRED_MODELS)
                ->orderBy('id')->chunkById(200, function ($rows) {
                    foreach ($rows as $row) {
                        DB::table('module_cleanup_attachment_archive')->updateOrInsert(
                            ['attachment_id' => $row->id],
                            ['metadata' => json_encode($row, JSON_THROW_ON_ERROR), 'archived_at' => now()],
                        );
                        DB::table('attachments')->where('id', $row->id)->delete();
                    }
                });
            if (Schema::hasTable('notifications')) {
                DB::table('notifications')->whereIn('type', self::RETIRED_NOTIFICATIONS)->delete();
            }
            foreach (['jobs', 'failed_jobs'] as $table) {
                if (! Schema::hasTable($table)) {
                    continue;
                }
                DB::table($table)->orderBy('id')->chunkById(200, function ($rows) use ($table) {
                    foreach ($rows as $row) {
                        $payload = json_decode($row->payload, true);
                        $classes = [$payload['data']['commandName'] ?? null, $payload['displayName'] ?? null];
                        $retired = array_merge(self::RETIRED_JOBS, self::RETIRED_NOTIFICATIONS);
                        if (array_intersect($classes, $retired)) {
                            DB::table($table)->where('id', $row->id)->delete();
                        }
                    }
                });
            }
        });

        Schema::withoutForeignKeyConstraints(function () use ($existing) {
            foreach ($existing as $name) {
                Schema::dropIfExists($name);
            }
            if (Schema::hasColumn('clients', 'nextcloud_folder_name')) {
                Schema::table('clients', function (Blueprint $table) {
                    $table->dropUnique('clients_nextcloud_folder_name_unique');
                    $table->dropColumn('nextcloud_folder_name');
                });
            }
            if (Schema::hasColumn('clients', 'nextcloud_photos_path')) {
                Schema::table('clients', fn (Blueprint $table) => $table->dropColumn('nextcloud_photos_path'));
            }
            if (Schema::hasColumn('users', 'last_tickets_viewed_at')) {
                Schema::table('users', fn (Blueprint $table) => $table->dropColumn('last_tickets_viewed_at'));
            }
        });
    }

    public function down(): void
    {
        throw new RuntimeException('La rimozione dei moduli non è reversibile con rollback. Ripristinare insieme il backup del database e la versione precedente del codice.');
    }
};
