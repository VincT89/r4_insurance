<?php
return ['backup_confirmed' => filter_var(env('MODULE_CLEANUP_BACKUP_CONFIRMED', false), FILTER_VALIDATE_BOOL)];
