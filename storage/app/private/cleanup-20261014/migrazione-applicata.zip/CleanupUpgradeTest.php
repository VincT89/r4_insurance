<?php
namespace Tests\Feature;

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\{DB, Schema};
use Tests\TestCase;

class CleanupUpgradeTest extends TestCase
{
    public function test_populated_upgrade_requires_backup_preserves_access_and_archives_only_retired_attachments(): void
    {
        // Dedicated in-memory connection: no configured/local database is accessed.
        config(['database.connections.cleanup_upgrade' => ['driver' => 'sqlite', 'database' => ':memory:', 'prefix' => '', 'foreign_key_constraints' => true]]);
        $previous = DB::getDefaultConnection();
        DB::setDefaultConnection('cleanup_upgrade');
        try {
            Schema::create('clients', fn (Blueprint $t) => [$t->id(), $t->string('name'), $t->string('tax_code'), $t->string('vat_number')]);
            Schema::create('users', fn (Blueprint $t) => [$t->id(), $t->string('email'), $t->string('password')]);
            Schema::create('projects', fn (Blueprint $t) => [$t->id(), $t->foreignId('client_id')->constrained()]);
            Schema::create('project_user', fn (Blueprint $t) => [$t->id(), $t->foreignId('project_id')->constrained(), $t->foreignId('user_id')->constrained()]);
            Schema::create('attachments', fn (Blueprint $t) => [$t->id(), $t->morphs('attachable'), $t->string('path')]);
            Schema::create('audit_logs', fn (Blueprint $t) => [$t->id(), $t->string('description')]);
            Schema::create('notifications', fn (Blueprint $t) => [$t->id(), $t->string('type')]);
            Schema::create('jobs', fn (Blueprint $t) => [$t->id(), $t->text('payload')]);
            DB::table('clients')->insert(['id' => 1, 'name' => 'Azienda dimostrativa', 'tax_code' => 'DEMO-CF', 'vat_number' => 'DEMO-IVA']);
            DB::table('users')->insert(['id' => 1, 'email' => 'admin@example.test', 'password' => 'hash-dimostrativo-da-conservare']);
            DB::table('projects')->insert(['id' => 1, 'client_id' => 1]);
            DB::table('project_user')->insert(['id' => 1, 'project_id' => 1, 'user_id' => 1]);
            DB::table('attachments')->insert([
                ['id' => 1, 'attachable_type' => 'App\\Models\\Client', 'attachable_id' => 1, 'path' => 'client/1/documento-demo.pdf'],
                ['id' => 2, 'attachable_type' => 'App\\Models\\Project', 'attachable_id' => 1, 'path' => 'project/1/documento-demo.pdf'],
            ]);
            DB::table('audit_logs')->insert(['description' => 'Storico dimostrativo da conservare']);
            DB::table('jobs')->insert(['payload' => json_encode(['data' => ['commandName' => 'App\\Jobs\\QueueHeartbeatJob']])]);
            $migration = require database_path('migrations/2026_10_14_120000_remove_retired_modules.php');
            $notification = (new \ReflectionClass($migration))->getConstant('RETIRED_NOTIFICATIONS')[0];
            DB::table('jobs')->insert(['payload' => json_encode(['displayName' => $notification, 'data' => ['commandName' => 'Illuminate\\Notifications\\SendQueuedNotifications']])]);
            DB::table('notifications')->insert(['type' => $notification]);
            DB::statement("ATTACH DATABASE ':memory:' AS unrelated");
            Schema::create('unrelated.external_scope_probe', fn (Blueprint $t) => $t->id());
            DB::connection()->enableQueryLog();
            DB::connection()->flushQueryLog();
            config(['module-cleanup.backup_confirmed' => false]);
            try {
                $migration->up();
                $this->fail('Unconfirmed destructive migration must stop.');
            } catch (\RuntimeException $exception) {
                $this->assertStringContainsString('backup', $exception->getMessage());
            }
            $this->assertStringNotContainsString('external_scope_probe', implode(' ', array_column(DB::connection()->getQueryLog(), 'query')));
            DB::connection()->disableQueryLog();
            $this->assertTrue(Schema::hasTable('projects'));
            $this->assertFalse(Schema::hasTable('client_user'));
            config(['module-cleanup.backup_confirmed' => true]);
            $migration->up();
            $this->assertFalse(Schema::hasTable('projects'));
            $this->assertSame(1, DB::table('client_user')->where('client_id', 1)->where('user_id', 1)->count());
            $this->assertSame('DEMO-CF', DB::table('clients')->value('tax_code'));
            $this->assertSame('hash-dimostrativo-da-conservare', DB::table('users')->value('password'));
            $this->assertSame(1, DB::table('attachments')->count());
            $this->assertSame('client/1/documento-demo.pdf', DB::table('attachments')->value('path'));
            $archive = json_decode(DB::table('module_cleanup_attachment_archive')->value('metadata'), true);
            $this->assertSame('project/1/documento-demo.pdf', $archive['path']);
            $this->assertSame(1, DB::table('audit_logs')->count());
            $this->assertSame(1, DB::table('jobs')->count());
            $this->assertSame(0, DB::table('notifications')->count());
            $migration->up();
            $this->assertSame(1, DB::table('client_user')->count());
            $this->assertTrue(Schema::hasTable('unrelated.external_scope_probe'));
        } finally {
            DB::setDefaultConnection($previous);
            DB::purge('cleanup_upgrade');
        }
    }
}
